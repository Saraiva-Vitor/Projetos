using System;

class Program {  
  //Função a)
  public static double fa(double x){
    return Math.Pow((x+5),2);
  }
  //Função b)
  public static double fb(double x){
    return (10+Math.Pow(x,2)-10*Math.Cos(2*Math.PI*x));
  }
  //Derivada da Função a)
  public static double dx_a_dy(double x, double h){
    return (fa(x+h) - fa(x))/h;
  }

  //Derivada da Função b)
  public static double dx_b_dy(double x, double h){
    return (fb(x+h) - fb(x))/h;
  }
  
  public static void Main (string[] args) {
    
    double h = 0.001;
    
    int min_a = -10;
    int max_a = 5;
    int min_b = -6;
    int max_b = 6;
    double alpha = 0.001;
    
    double xafinal = 0;

    //Valor de X aleatório para a letra a) 
    System.Random random = new System.Random();
    double xa = (random.NextDouble() * (max_a - min_a) + min_a);
    double xaaux = xa;

    while(dx_a_dy(xa,h) < (h *(-1)) || dx_a_dy(xa,h) > h){
      xa = xa + alpha * dx_a_dy(xa,h);
      if(fa(xa) > fa(xaaux)){
        xaaux = xa;
      }
      xafinal = xa;
      xa = (random.NextDouble() * (max_a - min_a) + min_a);
    }

    Console.WriteLine ($"X em a = {xa}");
    Console.WriteLine ($"X auxiliar em a = {xaaux}");
    Console.WriteLine ($"X final em a = {xafinal}");
    Console.WriteLine ($"Derivada de a = {dx_a_dy(xafinal,h)}");
      
    if (dx_a_dy(xafinal,h) < (h *(-1)) || dx_a_dy(xafinal,h) > h){
      Console.WriteLine("Tempo Esgotado");
    }

//-----------------------------------------------------------------
/*
    double xbfinal = 0;

    //Valor de X aleatório para a letra b) 
    System.Random random = new System.Random();
    double xb = (random.NextDouble() * (max_b - min_b) + min_b);
    double xbaux = xb;

    while(dx_b_dy(xb,h) < (h *(-1)) || dx_b_dy(xb,h) > h){
      xb = xb + alpha * dx_b_dy(xb,h);
      if(fb(xb) > fb(xbaux)){
        xbaux = xb;
      }
      xbfinal = xb;
      xb = (random.NextDouble() * (max_b - min_b) + min_b);
    }

    Console.WriteLine ($"X em b = {xb}");
    Console.WriteLine ($"X auxiliar em b = {xbaux}");
    Console.WriteLine ($"X final em b = {xbfinal}");
    Console.WriteLine ($"Derivada de b = {dx_b_dy(xbfinal,h)}");

    if (dx_b_dy(xbfinal,h) < (h *(-1)) || dx_b_dy(xbfinal,h) > h){
      Console.WriteLine("Tempo Esgotado");
    }*/
  }
}
