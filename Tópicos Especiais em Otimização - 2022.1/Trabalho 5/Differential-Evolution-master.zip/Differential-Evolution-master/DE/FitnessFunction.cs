﻿namespace DifferentialEvolution.DE
{
    public delegate double FitnessFunction(Individual solution, int dimensions);
}
